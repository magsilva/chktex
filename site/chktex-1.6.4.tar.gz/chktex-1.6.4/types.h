/*
 * Clone of <exec/types.h>, which could not be included because it's
 * (c) Commodore/Escom/Amiga/whatever.
 *
 */

#ifndef EXEC_TYPES_H
#define	EXEC_TYPES_H

#ifndef TRUE
#	define TRUE			1L
#endif
#ifndef FALSE
#	define FALSE		0L
#endif

#endif
